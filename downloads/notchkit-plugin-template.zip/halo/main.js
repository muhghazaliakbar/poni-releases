// Plugin NotchKit. Panduan lengkap: https://muhghazaliakbar.github.io/notchkit-releases/sdk.html
// Simpan berkas ini dan notch langsung memuat ulang plugin. console.log tampil di Pengaturan → Halo → Konsol.

var clicks = notch.storage.get('clicks') || 0;

function time() {
  var d = new Date();
  var pad = function (n) { return (n < 10 ? '0' : '') + n; };
  return pad(d.getHours()) + ':' + pad(d.getMinutes()) + (notch.settings.get('showSeconds') ? ':' + pad(d.getSeconds()) : '');
}

// Isi notch saat terbuka.
function render() {
  return ui.vstack([
    ui.text(notch.settings.get('greeting') + '!', { style: 'title' }),
    ui.text('Sekarang ' + time(), { style: 'caption' }),
    ui.hstack([
      ui.button('Klik aku', 'click', { symbol: 'lucide:pointer', style: 'primary' }),
      ui.button('Ulang', 'reset'),
      ui.text(clicks + ' klik', { color: 'secondary' })
    ])
  ], { spacing: 10 });
}

// Tampil di samping notch saat tertutup. Kembalikan null untuk menyembunyikan.
function compact() {
  return clicks > 0 ? { symbol: 'lucide:pointer', text: clicks + ' klik' } : null;
}

function onAction(action) {
  clicks = action === 'click' ? clicks + 1 : 0;
  notch.storage.set('clicks', clicks);
}

function onSettingsChanged(key, value) {
  console.log('pengaturan berubah:', key, value);
}
